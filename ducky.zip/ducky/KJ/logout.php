<?php
session_start(); // Start the session
session_destroy(); // Remove all session variables

header("Location: login.php"); // Redirect to login page

?>
