<?php
session_start(); // Start the session

// Database (insecure for simplicity)
$users = [
    'user1' => ['password' => 'pass1', 'role' => 'user'],
    'user2' => ['password' => 'pass2', 'role' => 'user'],
    'admin' => ['password' => 'adminpass', 'role' => 'admin'],
];


// Login Logic
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username']) && isset($_POST['password']) && isset($_POST['role'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role']; // Get the role from the request

    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        // We are now overwriting the users role if it was defined on the server
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $role; // Use the role from the request


        if($_SESSION['role'] == 'admin') {
            header("Location: admin_dashboard.php");
        } else {
            header("Location: user_dashboard.php");
        }
        exit;
    } else {
        $error = "Invalid username or password.";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>break the ROLE !!!!!</title>
</head>
<body>
    <h1>Login</h1>
    <!--  username: user1  password: pass1 -->
    <?php if (isset($error)) {
        echo '<p style="color: red;">' . $error . '</p>';
    } ?>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        <!-- Added a hidden input for the role -->
        <input type="hidden" name="role" id="role" value="user">
        <input type="submit" value="Login">
    </form>
</body>
</html>
