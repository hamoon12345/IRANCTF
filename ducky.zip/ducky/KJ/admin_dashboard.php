<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit;
}
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "Unauthorized to view this page";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Welcome to the Admin Dashboard, <?php echo $_SESSION['username']; ?>!</h1>
    <!DOCTYPE html>
<html language="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
  <meta property="og:url" content="https://DUCKY_CTF_2025" />
  <meta property="og:type" content="article" />
  <meta property="og:title" content="DUCKY CTF 2025" />
  <meta property="og:author" content="" />
  <meta property="og:description" content="Website pessoal" />
  <meta property="og:image:width" content="512" />
  <meta property="og:image:height" content="512" />
  <title> DUCKY CTF 2025 </title>
  <link rel="preload" as="image" href="bg.png">
  <link rel="stylesheet" type="text/css" href="css/styles.css" />
</head>

<body>
  <!DOCTYPE html>
  <html lang="en">

  <body>

    <h1>DUCKY CTF 2025</h1>

    <div class="link-container">
      
      <div class="description">Welcome to the Admin Dashboard!!!</div>

      
      <div class="description">are you looking for the FLAG?</div>

      <div class="description">WjJkeVozSm5jbWhvYUdob2FHaG9aMmRuWjJkbloyZG5aMmRuWjJkb1oyaG5hR0puWjNKblpHWmtaMnByYW10cVptZGthbVpyZG1SbVoydHVabVJyWjJSbWFHbHBhR3BrWm10bVpHcG9hbVprYW1ocVpHWnJhR3BrWm10cWEyUm1hbWhzYTJaa1ptcG9iR3RrYW1obWEyUm9hbXRtWkdwb2JHWnNMMmhzYTJocmJHWmthMnhyYUdSa2JHWm9abVJvYkdzS0wyeHJhR1pvWkdab2EyWmtabVJtWkhCcmFIQndaR1puY21keWNtZG1aMmdLTDJob2FHeHZjbmxyY205bmEyWmthMmR5ZEhSdFpHeHBhbTV6ZEdwM2NtZHJjM1pyYW1SMGJuZGxjbWxpWnlBdlRDQm1aR2RtWjJabVoyWm5abWRtY21keVozSmxZbVZpWlNCdVpXcHFhR3BvYVdWb2FtbGxhbWhsYW1obGFtaHFhbWhwWldwb1pXcG9hV3BvYVdwcWFHbHFhR2xsY21wb2FXVm8=
      </div>


    </div>

    
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-WJWR97BMWK"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag() { dataLayer.push(arguments); }
      gtag('js', new Date());

      gtag('config', 'G-WJWR97BMWK');
    </script>
  </body>

  </html>
    <a href="logout.php">Logout</a>
</body>
</html>
