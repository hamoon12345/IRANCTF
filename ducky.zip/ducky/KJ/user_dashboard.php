<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit;
}


?>
<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
</head>
<body>
    <h1>Welcome to the User Dashboard, <?php echo $_SESSION['username']; ?>!</h1>
    <p>This is a user page.</p>
    <a href="logout.php">Logout</a>
</body>
</html>
