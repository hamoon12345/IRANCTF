<?php
session_start();

// Mock user data (in real app, fetch from database)
$users = [
    1 => ['username' => 'FLAG', 'email' => 'FLAG@example.com', 'bio' => '/KJ'],
    2 => ['username' => 'bob', 'email' => 'bob@example.com', 'bio' => 'A coder.'],
    3 => ['username' => 'charlie', 'email' => 'charlie@example.com', 'bio' => 'A student.'],
];

// Check if the user requested a logout
if (isset($_GET['logout'])) {
    // Unset all session variables
    session_unset();
    // Destroy the session
    session_destroy();
     // Redirect to the same page to remove the query params
    header("Location: index.php");
     exit();
}

// Mock authentication (in real app, use login form)
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    $_SESSION['logged_in'] = true;
    $_SESSION['user_id'] = 1; // Automatically log in a user 1 for this example
}

// Get the user ID from the URL parameter
if (isset($_GET['user_id'])) {
    $requestedUserId = $_GET['user_id'];


    // Flawed Authorization Check (Still Vulnerable):
    if ($_SESSION['user_id'] != $requestedUserId )
    {
        $user = null; // do not allow other users to see the profile page.
    }
     else{
       if (isset($users[$requestedUserId])) {
             $user = $users[$requestedUserId];
         }else{
           $user = null;
        }
    }


} else {
    $user = null;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
</head>
<body>
    <h1>User Profile</h1>
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
        <p><a href="index.php?logout">Logout</a></p>
    <?php endif; ?>
    <?php if ($user): ?>
        <h2>User Name: <?php echo htmlspecialchars($user['username']); ?></h2>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
        <p><strong>Bio:</strong> <?php echo htmlspecialchars($user['bio']); ?></p>
    <?php else: ?>
       <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
             <p>You can only view your own profile.</p>
       <?php else: ?>
              <p>Please Login</p>
       <?php endif; ?>
    <?php endif; ?>

</body>
</html>