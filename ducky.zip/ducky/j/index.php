<?php

  $target_url = $_GET['url'];

  if (empty($target_url)) {
       $generated_url_parameter = "index.php?url=";
       echo '<!DOCTYPE html>
       <html>
       <head>
           <title>Online news site</title>
       </head>
       <body>
           <h1>Online news</h1>
           <p>There is no new news to show</p>
               <a href="' . $generated_url_parameter . '">Click here to see the news</a>
       </body>
       </html>';
     exit;
    }


  // Extremely vulnerable check (DO NOT DO THIS)
  $parsed_url = parse_url($target_url);
  if ($parsed_url['scheme'] === 'http' || $parsed_url['scheme'] === 'https')
      {
        echo '<!DOCTYPE html>
            <html>
            <head>
            <title>Redirecting...</title>
            </head>
            <body>
              <script>
                var url = "' . $target_url . '";
                  if (url.startsWith("http")){
                    alert("Congratulations, you were able to redirect!! This is from the next episode:/N " + url);
                    window.location.href = url;
                 } else{
                    alert("invalid url: " + url)
                  }
              </script>
            </body>
            </html>';

    } else {
        echo "Invalid URL scheme";
        http_response_code(400);
        exit;
    }
?>





