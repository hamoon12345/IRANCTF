<?php
function send_request_to_backend($request){
    $backend_url = "http://localhost:8001/index.php"; // Adjust if necessary

    $ch = curl_init($backend_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/plain'));

    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}


$request = file_get_contents('php://input');
$headers = getallheaders();

// Simulate proxy logic that always sets Content-Length
$contentLength = strlen($request);

$forwardedHeaders = "Content-Length: " . $contentLength . "\r\n";

foreach($headers as $key => $value){
  if($key !== 'Content-Length' && $key !== 'Transfer-Encoding'){
    $forwardedHeaders .= $key . ": " . $value . "\r\n";
  }
}

$forwardedHeaders .= "\r\n";

$result = send_request_to_backend($forwardedHeaders . $request);

echo $result;
?>
