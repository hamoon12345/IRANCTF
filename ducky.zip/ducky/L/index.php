<?php
$request_body = file_get_contents('php://input');
$headers = getallheaders();

// Simulate proxy logic:
// Check for Transfer-Encoding and handle chunked data if found
if(isset($headers['Transfer-Encoding']) && $headers['Transfer-Encoding'] === 'chunked'){
    $decoded_body = "";
    $chunks = explode("\r\n", $request_body);
    for($i = 0; $i < count($chunks)-1; $i+=2) {
        $chunk_length = hexdec($chunks[$i]);
        $decoded_body .= substr($chunks[$i+1],0,$chunk_length);
    }
} else {
    $decoded_body = $request_body;
}

// Check for request type (for simplicity)
if (strpos($decoded_body, 'GET /flag') !== false) {
    $flag = "/NBM";
    echo "Flag: " . $flag;
} else {
    echo "Welcome to HTTP Request Smuggling can you find the /flag ?";
    echo "<br>You sent: <pre>" . htmlspecialchars($decoded_body) . "</pre>";
}

?>
