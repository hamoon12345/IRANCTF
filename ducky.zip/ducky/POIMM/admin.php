<?php
if ($_SERVER['HTTP_X_ADMIN'] === "true") {
    echo "find the part2? but its tricky looking for key? /api-give-key/  /  -ZENqiIZyuJPfSiq68RPF3JkmVrYchOhNWkBeta8UDh1fG-T0eKlwGcb ";
} else {
    http_response_code(403);
    die("Admins only! (Prove your identity via headers HTTP_X_????? )");
}
?>
