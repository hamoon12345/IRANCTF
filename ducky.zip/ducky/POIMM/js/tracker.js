// Analytics tracking (unused)
function logVisit() {
    // TODO: Implement /internal-monitor endpoint
    fetch('/internal-monitor', { method: 'POST' });
}
