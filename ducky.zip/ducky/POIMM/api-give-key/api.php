<?php
// api.php

$flag = "your key for decryption is: 7pISrzQyZ1P3ILXQs5RF_RvfBULxk8ndy8pGNX5QgEU="; 
$allowed_ip = "127.0.0.1";


$user_ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];


$user_ip = trim(explode(',', $user_ip)[0]);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($user_ip === $allowed_ip) {
        http_response_code(200);
        die(json_encode([
            'status' => 'success',
            'message' => 'Welcome trusted user!',
            'flag' => $flag
        ]));
    } else {
        http_response_code(403);
        die(json_encode([
            'status' => 'error',
            'message' => "Forbidden - Your IP ($user_ip) is not allowed to see the api.php (:"
        ]));
    }
}
?>
