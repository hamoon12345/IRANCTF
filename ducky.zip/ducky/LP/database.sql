--
-- Dumping data for table `flag`
--

INSERT INTO `yearfieldnames` (`flagname`) VALUES
('/bb.html')

