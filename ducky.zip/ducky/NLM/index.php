<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Secure Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-box">
        <h1>🔒 Secure Login</h1>
        <form action="check.php" method="POST">
            <div class="input-group">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit">Login</button>
        </form>
	<!-- Debug: Maintenance account: test:test -->
        <!-- dont brute force please if you want the user: Admin -->
        <!-- want hint?  Examine both client-side and server-side authentication mechanisms /  another hint? PHP has interesting type comparison behaviors with hashes starting with '0e / the last hint ( still cant solve the challange?) all its about the coockies... -->
        
     </div>
</body>
</html>
