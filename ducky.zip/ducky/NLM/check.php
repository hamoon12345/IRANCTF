<?php
include 'config.php';


if (!isset($_COOKIE['session'])) {
    $default = base64_encode('user=guest');
    setcookie('session', $default, time() + 3600, '/');
}


$error = '';
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $hash = md5($password);
    $validHash = '0e215962017';

    if ($username === 'admin' && $hash == $validHash) {
        // Cookie manipulation vulnerability
        if (isset($_COOKIE['session'])) {
            $session = base64_decode($_COOKIE['session']);
            parse_str($session, $sessionData);
            
            if (isset($sessionData['admin']) && $sessionData['admin'] == '1') {
                die("<div class='login-box'><h1>Flag: $flag</h1></div>");
            }
        }
        $error = "⚠️ Insufficient privileges!";
    } else {
        $error = "❌ Invalid credentials!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Secure Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-box">
        <?php if ($error): ?>
            <h1>Access Denied</h1>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>
        <a href="index.php">← Back to login</a>
    </div>
</body>
</html>
