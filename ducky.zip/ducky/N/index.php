<?php
session_start();

// Emulating user authentication (VERY INSECURE!)
if (!isset($_SESSION['user_id'])) {
    // In a real app, you would authenticate and set $_SESSION['user_id']
    // For this vulnerable example, we set a default user id.
    $_SESSION['user_id'] = 1; // Default user id for demo
}

// Database emulation (VERY INSECURE!)
$users = [
    1 => [ 'name' => 'Alice', 'email' => 'alice@example.com', 'bio' => 'I am Alice' ],
    2 => [ 'name' => 'CTF',   'email' => 'CTF@example.com',   'bio' => '/M'   ],
    3 => [ 'name' => 'Charlie', 'email' => 'charlie@example.com', 'bio' => 'I am Charlie'],
];


// The Insecure part: Getting User ID directly from the URL
$user_id = $_GET['user_id'] ?? $_SESSION['user_id'];  // Using URL parameter if it is set, otherwise using the session user id
if (!isset($users[$user_id])) {
   echo "User Not found";
   http_response_code(404);
   exit;
}
$user = $users[$user_id];


// Display User Profile
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
</head>
<body>
    <h1>User Profile</h1>
    <h2>Name: <?php echo htmlspecialchars($user['name']); ?></h2>
    <p>Email: <?php echo htmlspecialchars($user['email']); ?></p>
    <p>Bio: <?php echo htmlspecialchars($user['bio']); ?></p>
    <p>the ALICE user_id=1</p>
</body>
</html>







