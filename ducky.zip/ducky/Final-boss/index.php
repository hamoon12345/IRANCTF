<!DOCTYPE html>
<html>
<head>
    <title>FINAL BOSS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="game-ui">
        <h1>🔥 DEFEAT THE BOSS TO GET THE FLAG! 🔥</h1>
        <img src="boss.jpg" class="boss-sprite" alt="Final Boss">
        <p>Hint: The boss hides secrets in darkness.</p>
        <!-- Debug: /dungeon locked. Use /backup for clues -->
    </div>
</body>
</html>
