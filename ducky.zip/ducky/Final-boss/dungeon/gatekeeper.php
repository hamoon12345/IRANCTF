<?php
// Part 2: Requires cookie "power=OVER9000" and User-Agent "DragonSlayer"
$flag_part2 = "1n_Th3_";

if ($_SERVER['HTTP_USER_AGENT'] !== 'DragonSlayer') {
    die("<h1>You are not the chosen one! 🐉</h1>");
}

if (isset($_COOKIE['power']) && base64_decode($_COOKIE['power']) === "OVER9000") {
    echo $flag_part2;
} else {
    setcookie("power", base64_encode("Weakling"), time()+3600, "/");
    die("<h1>Your power level is too low! 💢</h1>");
}
?>
